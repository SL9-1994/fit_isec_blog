#include <stdio.h>

int main() {
  struct {
    char buf[010];
    int check;
  } s;

  s.check = 0;

  printf("Check value is: %d\n", s.check);
  printf("Input something: ");

  fgets(s.buf, 0x40, stdin);

  if (s.check != 0) {
    printf("You win! The check value is: %d\n", s.check);
  } else {
    printf("Try again...\n");
  }

  return 0;
}
